import './i18n.js';
export function toast(message){const box=document.querySelector('#toast');if(!box)return;box.textContent=message;box.hidden=false;clearTimeout(box.timer);box.timer=setTimeout(()=>box.hidden=true,4200)}
document.querySelector('#print-cv')?.addEventListener('click',()=>window.print());
document.querySelectorAll('[data-copy]').forEach(button=>button.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(button.dataset.copy);toast('WeChat ID copied: '+button.dataset.copy)}catch{toast('WeChat ID: '+button.dataset.copy)}}));
