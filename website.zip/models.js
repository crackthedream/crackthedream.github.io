import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {DRACOLoader} from 'three/addons/loaders/DRACOLoader.js';
const data={
 savour:{file:'savour-product.glb',parts:[
  ['Whole product','A glance, with context.','The printed black frame and external right-temple module follow the project prototype. Explore the open frame, flat temples and camera housing, then try the AR-to-diary flow below.',[]],
  ['Scene camera','Recognize the scene.','The right-temple camera supplies the image input. In the software prototype, detection and second-stage classification identify food regions.',['Scene camera','Camera optical glass','Recognition module']],
  ['Frame & optics','Keep information in view.','The open apertures and tapered frame follow the photographed prototype. A half-mirror display was explored separately; the AR interaction reveals information progressively.',['Optical frame','Bridge','Nose support']],
  ['Recognition module','Connect image to feedback.','The external right-temple housing and exposed flexible connector follow the original hardware layout. My work connected the recognition pipeline to stable AR overlays.',['Recognition module','Module top','Flexible camera connector']],
  ['Temples & fit','Think about wearing.','Broad, flat printed temples taper into curved earpieces. The model preserves the prototype’s asymmetric hardware placement, hinge details and visible print texture.',['Temple arm','Temple hinge','Temple housing','Temple access','Hinge screw']]]},
 xband:{file:'xband-product.glb',parts:[
  ['Whole product','A routine with a clear owner.','A graphite band, removable contact lining and control module bring records, confirmation and a stop action into one wearable concept.',[]],
  ['Control module','Read, confirm, stop.','The rounded black module has recessed diagonal channels and a separate metal status strip, following the original design. In the proposed interaction, a signal alone does not initiate a support session.',['Control module','Module face','Status panel','Status light']],
  ['Contact lining','Separate contact from electronics.','A removable soft lining carries contact zones for the proposed recording and stimulation architecture. It can be cleaned or replaced independently.',['Removable contact lining','Electrode zone','Lining texture']],
  ['One-hand adjustment','Position, pull, check.','The pull tab and metal grip make tightening a single-handed action after initial positioning. Fit and contact are checked before continuing.',['Pull tab','Metal pull grip','Flexible outer band']],
  ['Charging cradle','A place to return to.','A separate cradle gives the device a consistent charging and storage point within the daily routine.',['Charging cradle','Charging contact']]]},
 teahouse:{file:'teahouse.glb',parts:[
  ['Whole space','Enter a different rhythm.','Thresholds, screens, tea tables and a courtyard create a gradual transition from everyday space to the Jianghu story.',[],[-130,-95,155],[75,65,8]],
  ['Entrance','A threshold into the story.','The entrance compresses the view before opening it. Receiving an identity card gives visitors a reason to explore the rest of the space.',[],[4,-33,33],[48,32,9]],
  ['Tea seating','A place to stay.','Seating, tableware and framed views carry the atmosphere at human scale. The drink becomes a service touchpoint within the spatial story.',[],[140,-20,105],[114,77,6]],
  ['Courtyard','Encounter and share.','The courtyard connects interaction, task completion and photo opportunities while preserving visual relationships between zones.',[],[-60,115,110],[40,75,6]]]},
};
const normalize=s=>s.toLowerCase().replace(/[^a-z0-9]/g,'');
export async function mountModel(root){
 const cfg=data[root.dataset.model],tea=root.dataset.model==='teahouse',host=root.querySelector('.model-canvas');
 const scene=new THREE.Scene();scene.background=new THREE.Color(tea?0xe9e6df:0xebecee);
 const camera=new THREE.PerspectiveCamera(38,1,.01,250);
 const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=tea?1.3:1.0;
 if(!tea){renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;}
 renderer.domElement.setAttribute('aria-label',`Rotate, zoom and pan the ${root.dataset.model} model`);renderer.domElement.tabIndex=0;
 host.append(renderer.domElement);
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=false;controls.enablePan=true;controls.minPolarAngle=.015;controls.maxPolarAngle=Math.PI-.015;controls.minDistance=.4;controls.maxDistance=25;
 scene.add(new THREE.HemisphereLight(0xf5f6fa,0x63646a,tea?2.6:.9));
 for(const [color,power,xyz] of [[0xffffff,tea?3.5:2.1,[4,6,4]],[0xe3ebff,tea?2:1.1,[-5,2,-2]],[0xfff5e7,tea?1:.45,[1,3,-5]]]){const light=new THREE.DirectionalLight(color,power);light.position.set(...xyz);if(!tea&&xyz[0]===4){light.castShadow=true;light.shadow.mapSize.set(1024,1024);Object.assign(light.shadow.camera,{left:-5,right:5,top:5,bottom:-5,near:.1,far:20});light.shadow.bias=-.0002;light.shadow.normalBias=.025;light.shadow.radius=4;}scene.add(light)}
 // An offline studio-light environment gives metallic parts usable reflections.
 const room=new THREE.Scene();room.background=new THREE.Color(.18,.19,.21);
 const lightPlane=(pos,size,intensity)=>{const plane=new THREE.Mesh(new THREE.PlaneGeometry(...size),new THREE.MeshBasicMaterial({color:new THREE.Color(1,1,1).multiplyScalar(intensity),side:THREE.DoubleSide}));plane.position.set(...pos);plane.lookAt(0,0,0);room.add(plane)};
 lightPlane([0,5,0],[5,8],3);lightPlane([-4,2,0],[2,7],2);lightPlane([4,1,-3],[3,4],2.5);
 const pmrem=new THREE.PMREMGenerator(renderer);const env=pmrem.fromScene(room,.02);scene.environment=env.texture;scene.environmentIntensity=tea?1:.65;pmrem.dispose();room.traverse(o=>{o.geometry?.dispose();o.material?.dispose()});
 const draco=new DRACOLoader();draco.setDecoderPath('/vendor/draco/');draco.setWorkerLimit(2);
 const loader=new GLTFLoader();loader.setDRACOLoader(draco);
 const gltf=await loader.loadAsync('/assets/'+cfg.file+(tea?'':'?v=3'),progress=>{if(progress.total)root.querySelector('.model-loading').textContent=`Loading the 3D model… ${Math.round(progress.loaded/progress.total*100)}%`});
 const model=gltf.scene;const box=new THREE.Box3().setFromObject(model),center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3());const scale=(tea?8:4)/Math.max(size.x,size.y,size.z);
 model.scale.setScalar(scale);model.position.copy(center).multiplyScalar(-scale);scene.add(model);model.updateMatrixWorld(true);
 const meshes=[];model.traverse(o=>{if(o.isMesh){o.castShadow=!tea;o.receiveShadow=!tea;o.material=Array.isArray(o.material)?o.material.map(m=>m.clone()):o.material.clone();for(const m of [].concat(o.material)){m.side=THREE.DoubleSide;m.userData.originalEmissive=m.emissive?.clone();m.userData.originalIntensity=m.emissiveIntensity;for(const key of ['map','normalMap'])if(m[key])m[key].anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());}meshes.push(o)}});
 if(!tea){const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.ShadowMaterial({opacity:.12}));floor.rotation.x=-Math.PI/2;floor.position.y=-size.y*scale/2-.03;floor.receiveShadow=true;scene.add(floor);}
 let frame=0,selected=0;const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const render=()=>renderer.render(scene,camera);
 const resize=()=>{const w=host.clientWidth,h=host.clientHeight;if(w&&h){renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();render()}};
 new ResizeObserver(resize).observe(host);controls.addEventListener('change',render);controls.addEventListener('start',()=>cancelAnimationFrame(frame));
 const matchPart=(mesh,part)=>part[3].some(prefix=>normalize(mesh.name).startsWith(normalize(prefix)));
 function select(index,instant=false){
  selected=index;const part=cfg.parts[index];root.querySelectorAll('[data-part]').forEach(b=>{const on=Number(b.dataset.part)===index;b.classList.toggle('active',on);b.setAttribute('aria-pressed',String(on))});
  root.querySelector('.part-description').innerHTML=`<h3>${part[1]}</h3><p>${part[2]}</p>`;
  for(const mesh of meshes)for(const m of [].concat(mesh.material)){if(m.emissive){m.emissive.copy(m.userData.originalEmissive);m.emissiveIntensity=m.userData.originalIntensity;if(index&&matchPart(mesh,part)){m.emissive.set(0x2433c0);m.emissiveIntensity=.24}}}
  let target=new THREE.Vector3(),position=new THREE.Vector3(5,3.7,6.5);
  if(tea){const convert=v=>new THREE.Vector3(v[0],v[2],-v[1]).sub(center).multiplyScalar(scale);position=convert(part[4]);target=convert(part[5])}
  else if(index){const bounds=new THREE.Box3();meshes.filter(m=>matchPart(m,part)).forEach(m=>bounds.expandByObject(m));if(!bounds.isEmpty()){target=bounds.getCenter(new THREE.Vector3());const extent=bounds.getSize(new THREE.Vector3()).length();const direction=target.clone().normalize();direction.y+=.8;direction.z+=1.2;position=target.clone().add(direction.normalize().multiplyScalar(Math.max(2.8,extent*1.3)))}}
  cancelAnimationFrame(frame);const p0=camera.position.clone(),t0=controls.target.clone(),start=performance.now(),duration=instant||reduced?0:700;
  const animate=now=>{const f=duration?Math.min(1,(now-start)/duration):1,e=1-(1-f)**3;camera.position.lerpVectors(p0,position,e);controls.target.lerpVectors(t0,target,e);controls.update();render();if(f<1)frame=requestAnimationFrame(animate)};frame=requestAnimationFrame(animate);
 }
 root.querySelector('.model-parts').innerHTML=cfg.parts.map((p,i)=>`<button data-part="${i}" aria-pressed="false"><span>0${i+1}</span>${p[0]}</button>`).join('');
 root.querySelectorAll('[data-part]').forEach(b=>b.addEventListener('click',()=>select(Number(b.dataset.part))));
 root.querySelector('[data-model-reset]').addEventListener('click',()=>select(0));
 const expand=root.querySelector('[data-model-expand]');const close=()=>{root.classList.remove('expanded');root.removeAttribute('role');root.removeAttribute('aria-modal');root.removeAttribute('aria-label');document.body.style.overflow='';expand.textContent='Expand view ⛶';resize();expand.focus()};
 expand.addEventListener('click',()=>{if(root.classList.contains('expanded'))close();else{root.classList.add('expanded');root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-label','Expanded 3D product view');document.body.style.overflow='hidden';expand.textContent='Close view ×';resize()}});
 root.addEventListener('keydown',e=>{if(e.key!=='Tab'||!root.classList.contains('expanded'))return;const items=[...root.querySelectorAll('button,canvas[tabindex]')].filter(x=>!x.disabled);if(e.shiftKey&&document.activeElement===items[0]){e.preventDefault();items.at(-1).focus()}else if(!e.shiftKey&&document.activeElement===items.at(-1)){e.preventDefault();items[0].focus()}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&root.classList.contains('expanded'))close()});
 renderer.domElement.addEventListener('keydown',e=>{const key=e.key;if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','-','0'].includes(key))return;e.preventDefault();cancelAnimationFrame(frame);const offset=camera.position.clone().sub(controls.target),s=new THREE.Spherical().setFromVector3(offset);if(key==='ArrowLeft')s.theta-=.14;if(key==='ArrowRight')s.theta+=.14;if(key==='ArrowUp')s.phi=Math.max(.05,s.phi-.14);if(key==='ArrowDown')s.phi=Math.min(Math.PI-.05,s.phi+.14);if(key==='+')s.radius=Math.max(.4,s.radius*.9);if(key==='-')s.radius=Math.min(25,s.radius*1.1);if(key==='0'){select(0);return}camera.position.copy(controls.target).add(new THREE.Vector3().setFromSpherical(s));controls.update()});
 const pointer=new THREE.Vector2(),ray=new THREE.Raycaster();let down;
 renderer.domElement.addEventListener('pointerdown',e=>down=[e.clientX,e.clientY]);
 renderer.domElement.addEventListener('pointerup',e=>{if(tea||!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>5)return;const b=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-b.left)/b.width*2-1,-(e.clientY-b.top)/b.height*2+1);ray.setFromCamera(pointer,camera);const hit=ray.intersectObjects(meshes,false)[0];if(hit){const i=cfg.parts.findIndex((p,i)=>i>0&&matchPart(hit.object,p));if(i>0)select(i)}});
 root.querySelector('.model-loading').hidden=true;resize();select(0,true);draco.dispose();
 window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);controls.dispose();renderer.dispose();env.dispose()},{once:true});
}
