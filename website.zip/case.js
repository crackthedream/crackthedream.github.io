import './site.js';
const model=document.querySelector('[data-model]');
if(model){import('./models.js?v=3').then(m=>m.mountModel(model)).catch(e=>{model.querySelector('.model-loading').textContent='The 3D view could not load. Refresh to retry; the original project images are below.';console.error(e)})}
const host=document.querySelector('#interactive-demo');
if(host){const kind=host.dataset.demo;const file=kind==='drone'||kind==='research'?'./simulations.js?v=3':`./demos/${kind}.js?v=20260913c`;import(file).then(m=>m.mountDemo(host,kind)).catch(e=>{host.textContent='The demonstration could not load. Please refresh to retry.';console.error(`Demo ${kind}: ${e.stack||e}`)})}
