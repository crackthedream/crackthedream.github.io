import {toast} from '../site.js';
import {createSchedule,addTask,reschedule,clock,minutes,xbandTransition,parseScheduleRequest} from '../demo-state.js?v=3';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const button=(label,action,cls='')=>`<button type="button" class="app-button ${cls}" data-action="${action}">${label}</button>`;
const nav=(items,active)=>`<nav class="app-tabs" aria-label="Prototype screens">${items.map(([id,label])=>`<button data-tab="${id}" aria-pressed="${id===active}" class="${id===active?'active':''}">${label}</button>`).join('')}</nav>`;
const frame=(name,content,theme,note)=>`<div class="prototype ${theme}"><div class="prototype-bar"><strong>${name}</strong><span>INTERACTIVE PROTOTYPE</span><button data-action="reset" aria-label="Reset ${name} demo">Reset ↺</button></div>${content}<p class="prototype-note">${note}</p></div>`;
export function mountDemo(root){
 let step=0,identity='',tea='',complete=false;
 const identities=[['The Wanderer','Discover an unexpected view.'],['The Scholar','Find a quiet detail worth remembering.'],['The Guardian','Bring a companion into the story.']];
 function render(){
  let body='';
  if(step===0)body=`<span class="micro-label">01 / RECEIVE AN IDENTITY</span><h3>Who will you be<br>for this visit?</h3><div class="identity-options">${identities.map(([n,d],i)=>`<button data-identity="${i}"><span>0${i+1}</span><b>${n}</b><p>${d}</p><em>Choose this identity ↗</em></button>`).join('')}</div>`;
  if(step===1)body=`<span class="micro-label">02 / MAKE A CHOICE</span><h3>Welcome,<br>${identity}.</h3><p>A themed drink turns the first pause into part of the story.</p><div class="tea-options">${['Jasmine green tea','Roasted oolong','Osmanthus black tea'].map((t,i)=>`<button data-tea="${i}"><span>0${i+1}</span><b>${t}</b><small>${['Light & floral','Warm & rounded','Fragrant & mellow'][i]}</small></button>`).join('')}</div>${button('← Choose another identity','back','subtle')}`;
  if(step===2)body=`<span class="micro-label">03 / FOLLOW A SMALL QUEST</span><h3>A reason<br>to explore.</h3><div class="quest-card"><span>${identity}</span><h4>${identities.find(x=>x[0]===identity)[1]}</h4><p>Your tea: ${tea}</p><ol><li>Pass through the entrance.</li><li>Find a tea seat with a framed view.</li><li>Visit the courtyard and collect a memory.</li></ol></div>${button('Complete the visit','complete')}${button('← Change the tea','back','subtle')}`;
  if(step===3)body=`<span class="micro-label">04 / TAKE THE MEMORY WITH YOU</span><h3>A small visit.<br>A story to keep.</h3><div class="keepsake"><span>JIANGHU TEAHOUSE</span><h4>${identity}</h4><p>“A new view often begins<br>with a slower step.”</p><small>${tea} · Courtyard visit complete</small></div>${button('Try another identity','reset')}`;
  root.innerHTML=frame('Jianghu Teahouse',`<div class="tea-service"><div class="tea-service-image"><img src="/assets/tea-entry.webp" alt="Original teahouse entrance render"><span>ENTER → STAY → EXPLORE → REMEMBER</span></div><div class="tea-service-flow">${body}</div></div>`,'tea-app','Illustrative service walkthrough based on the original identity-card, menu and quest flow. Names and short text are adapted for this website; no booking or purchase is made.');
  root.onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.identity){identity=identities[Number(b.dataset.identity)][0];step=1}if(b.dataset.tea){tea=['Jasmine green tea','Roasted oolong','Osmanthus black tea'][Number(b.dataset.tea)];step=2}if(b.dataset.action==='complete')step=3;if(b.dataset.action==='back')step=Math.max(0,step-1);if(b.dataset.action==='reset'){step=0;identity='';tea=''}render()};
 }
 render();
}
