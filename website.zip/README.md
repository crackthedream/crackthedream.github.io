# Sun Wei — Personal Homepage

Bilingual personal portfolio for Industrial Design, human–computer interaction, research and interactive prototypes.

GitHub Pages address: https://crackthedream.github.io/

The repository contains the published website and presentation assets. Serve its root using an HTTP server to preview locally. All interface dependencies are included. Original project material and third-party libraries retain their respective rights; the Three.js license is included in `vendor/`.
