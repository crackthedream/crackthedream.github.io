export const clone=x=>JSON.parse(JSON.stringify(x));
export const minutes=s=>Number(s.split(':')[0])*60+Number(s.split(':')[1]);
export const clock=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
export const overlap=(a,b)=>a.start<b.start+b.duration&&b.start<a.start+a.duration;
export function parseScheduleRequest(text){
 const match=text.trim().match(/^add\s+(.+?)\s+at\s+(\d{1,2}:\d{2})(?:\s+for\s+(\d+)\s+minutes?)?[.!]?$/i)||text.trim().match(/^(?:添加|新增|安排)\s*(.+?)\s*(?:在|于)\s*(\d{1,2}[:：]\d{2})\s*(?:持续\s*(\d+)\s*分钟)?[。！.!]?$/);
 if(!match)return{ok:false,reason:'Try “Add Reading at 18:00 for 30 minutes”, or choose the group-discussion example below.'};
 const [hour,minute]=match[2].split(/[:：]/).map(Number),start=hour*60+minute,duration=Number(match[3]||30);
 if(hour>23||minute>59||duration<5||start+duration>1440)return{ok:false,reason:'Use a valid 24-hour time and a duration that fits today.'};
 return{ok:true,title:match[1].trim(),start,duration};
}
export function createSchedule(){return[{id:'class',title:'Interaction design class',start:840,duration:90,fixed:true,done:false},{id:'reading',title:'Read an HCI paper',start:960,duration:60,fixed:false,done:false},{id:'slides',title:'Prepare project slides',start:1050,duration:60,fixed:false,done:false}]}
export function addTask(tasks,task){const conflicts=tasks.filter(t=>overlap(t,task));return conflicts.length?{ok:false,conflicts}:{ok:true,tasks:[...tasks,task].sort((a,b)=>a.start-b.start)}}
export function reschedule(tasks,newTask){
 const fixed=tasks.filter(t=>t.fixed||t.done),movable=tasks.filter(t=>!t.fixed&&!t.done).sort((a,b)=>a.start-b.start);
 if(fixed.some(t=>overlap(t,newTask)))return{ok:false,reason:'This overlaps a fixed or completed item. Choose another time.'};
 const result=[...clone(fixed),clone(newTask)],moved=[];
 for(const source of movable){const t=clone(source);let n=0;while(result.some(x=>overlap(t,x))&&n++<100){const conflicts=result.filter(x=>overlap(t,x));t.start=Math.max(...conflicts.map(x=>x.start+x.duration))}if(t.start+t.duration>1440)return{ok:false,reason:'There is not enough room today. Choose a shorter task or another day.'};if(t.start!==source.start)moved.push({title:t.title,from:source.start,to:t.start});result.push(t)}
 return{ok:true,tasks:result.sort((a,b)=>a.start-b.start),moved};
}
export function directionCue(dx,dz,heading=0){
 const right=dx*Math.cos(heading)+dz*Math.sin(heading),forward=dx*Math.sin(heading)-dz*Math.cos(heading),distance=Math.hypot(dx,dz);
 if(distance>12||forward<-.6)return{direction:'none',left:false,right:false,level:0,distance};
 const angle=Math.atan2(right,forward);const direction=Math.abs(angle)<.3?'front':angle<0?'left':'right';
 return{direction,left:direction!=='right',right:direction!=='left',level:distance<=3?3:distance<=6?2:1,distance};
}
export function xbandTransition(state,event){
 const s={...state};
 if(event==='reset')return{stage:'fit',contact:false,pain:3};
 if(event==='fit'&&s.contact)s.stage='log';
 if(event==='record'&&s.stage==='log')s.stage='confirm';
 if(event==='start'&&s.stage==='confirm'&&s.contact)s.stage='session';
 if(event==='stop'&&s.stage==='session')s.stage='complete';
 if(event==='skip'&&s.stage==='confirm')s.stage='complete';
 return s;
}
