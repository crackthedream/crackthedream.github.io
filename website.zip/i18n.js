// Translate presentation text while keeping the interaction state and user input intact.
const records=new WeakMap(),attributes=new WeakMap();
const translatedAttributes=['aria-label','alt','title','placeholder'];
let language='en',dictionary={},patterns=[],terms=[];
const originalTitle=document.title;
const normalize=s=>s.replace(/\s+/g,' ').trim();
function translate(source,element){
 if(language==='en'||!source.trim())return source;
 const key=normalize(source),context=element?.closest('[data-demo]')?.dataset.demo;let result=dictionary[key+' @'+context]??dictionary[key];
 if(result===undefined){for(const [regex,replacement] of patterns){if(regex.test(key)){result=key.replace(regex,replacement);break;}}}
 if(result===undefined)return source;
 for(const [from,to] of terms)result=result.split(from).join(to);
 return source.match(/^\s*/)[0]+result+source.match(/\s*$/)[0];
}
function excluded(node){return node.parentElement?.closest('script,style,textarea,[data-user-content],[data-language-control]')}
function textNode(node){
 if(excluded(node))return;
 let record=records.get(node);
 if(!record||record.shown!==node.nodeValue)record={source:node.nodeValue,shown:node.nodeValue};
 const next=translate(record.source,node.parentElement);
 if(node.nodeValue!==next)node.nodeValue=next;
 record.shown=next;records.set(node,record);
}
function elementAttributes(element){
 if(element.closest('[data-language-control],[data-user-content]'))return;
 let map=attributes.get(element);if(!map){map=new Map();attributes.set(element,map);}
 for(const name of translatedAttributes){
  const value=element.getAttribute(name);if(value===null)continue;
  let record=map.get(name);if(!record||record.shown!==value)record={source:value,shown:value};
  const next=translate(record.source,element);if(value!==next)element.setAttribute(name,next);
  record.shown=next;map.set(name,record);
 }
}
function localize(root){
 if(root.nodeType===Node.TEXT_NODE){textNode(root);return;}
 if(root.nodeType!==Node.ELEMENT_NODE)return;
 if(root.matches('script,style,textarea,[data-user-content],[data-language-control]'))return;
 elementAttributes(root);
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT);
 for(let node=walker.nextNode();node;node=walker.nextNode()){
  if(node.nodeType===Node.TEXT_NODE)textNode(node);else elementAttributes(node);
 }
}
const observer=new MutationObserver(mutations=>{
 for(const mutation of mutations){
  if(mutation.type==='characterData')textNode(mutation.target);
  else if(mutation.type==='attributes')elementAttributes(mutation.target);
  else for(const node of mutation.addedNodes)localize(node);
 }
});
function selectLanguage(next,announce=false){
 language=next==='zh'?'zh':'en';
 document.documentElement.lang=language==='zh'?'zh-CN':'en';
 document.documentElement.dataset.language=language;
 document.title=translate(originalTitle);
 observer.disconnect();localize(document.body);
 observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:translatedAttributes});
 document.querySelectorAll('[data-language]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.language===language)));
 try{localStorage.setItem('sunwei-homepage-language',language)}catch{}
 if(announce){
  const url=new URL(location.href);url.searchParams.set('lang',language);history.replaceState(null,'',url);
  const status=document.querySelector('#language-status');if(status)status.textContent=language==='zh'?'已切换为中文':'Switched to English';
 }
}
async function init(){
 try{
  const response=await fetch('/locales/zh.json');if(!response.ok)throw new Error('Language file unavailable');
  const content=await response.json();dictionary=content.strings;terms=Object.entries(content.terms||{}).sort((a,b)=>b[0].length-a[0].length);patterns=(content.patterns||[]).map(([source,target])=>[new RegExp(source),target]);
  let saved;try{saved=localStorage.getItem('sunwei-homepage-language')}catch{}
  const requested=new URL(location.href).searchParams.get('lang');
  selectLanguage(['zh','en'].includes(requested)?requested:saved);
  document.querySelectorAll('[data-language]').forEach(button=>{button.disabled=false;button.addEventListener('click',()=>selectLanguage(button.dataset.language,true))});
 }catch(error){
  const status=document.querySelector('#language-status');if(status)status.textContent='Language switch unavailable / 语言切换暂不可用';console.error(error);
 }
}
init();
